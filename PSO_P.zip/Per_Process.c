#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <sys/types.h>
#include <string.h>
#include <math.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
pid_t CreateProcess()
{
    pid_t proces = fork();
    if (proces < 0)
    {
        perror("Eroare la crearea procesului");
        exit(0);
    }
    return proces;
}

int CreateSocket(const char *ipAddress, const char *portNumber)
{
    int descriptor, portNum, n;
    struct sockaddr_in adresaServer;
    struct hostent *server;

    // char buffer[256];

    portNum = atoi(portNumber);
    descriptor = socket(AF_INET, SOCK_STREAM, 0);

    if (descriptor < 0)
    {
        printf("Eroare la crearea descriptorului!");
        exit(0);
    }
    bzero((char *)&adresaServer, sizeof(adresaServer));
    adresaServer.sin_family = AF_INET;
    adresaServer.sin_addr.s_addr = inet_addr(ipAddress);
    adresaServer.sin_port = htons(portNum);

    int Conectare = connect(descriptor, (struct sockaddr *)&adresaServer, sizeof(adresaServer));

    if (Conectare < 0)
    {
        printf("Eroare la conectare!\n");
        exit(0);
    }
    return descriptor;
}

char *getMyIpAddress()
{
    struct ifaddrs *ifap = NULL, *ifa = NULL;
    struct sockaddr_in *sa;

    int verify = getifaddrs(&ifap);
    if (verify == -1)
    {
        printf("error\n");
        exit(0);
    }

    char *wifiIpAddress = (char *)malloc(INET_ADDRSTRLEN);

    for (ifa = ifap; ifa != NULL; ifa = ifa->ifa_next)
    {
        if (ifa->ifa_addr != NULL && ifa->ifa_addr->sa_family == AF_INET)
        {
            sa = (struct sockaddr_in *)ifa->ifa_addr;
            if (strstr(ifa->ifa_name, "enp0s3") != NULL)
            {
                strncpy(wifiIpAddress, inet_ntoa(sa->sin_addr), INET_ADDRSTRLEN);
                break;
            }
        }
    }
    freeifaddrs(ifap);
    // printf("Adresa IP este:   %s\n",wifiIpAddress);

    return wifiIpAddress;
}