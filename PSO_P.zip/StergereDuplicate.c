#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int NrCuvinte(const char* filename)
{
	FILE* f = fopen(filename, "r");
	char cv = fgetc(f);
	int count = 1;

	while (cv != EOF)
	{
		if (cv == ' ' || cv == '\n')
			count++;
		cv = fgetc(f);
	}
	fclose(f);
	return count;
}
int NrLinii(const char * filename)
{
	FILE* f = fopen(filename, "r");
	char cv = fgetc(f);
	int count = 1;

	while (cv != EOF)
	{
		if (cv == '\n')
			count++;
		cv = fgetc(f);
	}
	fclose(f);
	return count;
}
void Delete(const char* filename)
{
    int f=open(filename,O_RDONLY);
	if(f==-1)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	int x=NrCuvinte(filename);
	char **vector=(char**)malloc(sizeof(char*)*x);
	
	char buffer[10000];
	int nr=NrLinii(filename);
	
    for(int i=0;i<x;i++)
    vector[i]=(char*)malloc(10);

    char c;
	int j=0,k=0;
	ssize_t bytesRead;
	while((bytesRead=read(f,&c,1))>0)//asa memorez cuvintele din fisier intr-un vector de cuvinte
	{
	    if(c=='\n'|| c==' ')
	    {
            j++;k=0;
        }
        else{
            vector[j][k]=c;
            k++;
        }
	}

    close(f);
	for (int m = 0; m < x; m++) {
		for (int n = m+1; n < x; n++) {
			if (strcmp(vector[m], vector[n]) == 0)
			{
				for (int l = n; l < x-1; l++)
					strcpy(vector[l], vector[l + 1]);
				x--;
			}
		}
	}
	char** vector_nou = (char**)malloc(sizeof(char*) * x);
	for (int i = 0; i < x; i++)
		vector_nou[i]=strdup(vector[i]);


    int fd=open(filename,O_WRONLY);

	if (fd==-1)
	{
		printf("Eroare la deschiderea fisierului!\n");
		exit(0);
	}

    for(int i=0;i<x;i++)
    {
        write(fd,vector_nou[i],strlen(vector_nou[i]));
        write(fd," ",1);
    }

	close(fd);
}
