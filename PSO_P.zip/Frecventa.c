#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
int NrCuvinte (const char* filename)
{
    int fd=open(filename,O_RDONLY);
	
	if(fd==-1)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	char c;
	int count=1;
	ssize_t bytesRead;
	while((bytesRead=read(fd,&c,1))>0)
	{
	    if(c==' '|| c=='\n')
	    count++;
	}
	close(fd);
	return count;
}

int NrLinii(const char* filename)
{
	int fd=open(filename,O_RDONLY);
	
	if(fd==-1)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	char c;
	int count=1;
	ssize_t bytesRead;
	while((bytesRead=read(fd,&c,1))>0)
	{
	    if(c=='\n')
	    count++;
	}
	close(fd);
	return count;
}

int Frecventa(const char* filename, char* cuv)
{
    int f=open(filename,O_RDONLY);
	if(f==-1)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	int x=NrCuvinte(filename);
	char **vector=(char**)malloc(sizeof(char*)*x);
	
	char buffer[10000];
	int i=0;
	int nr=NrLinii(filename);
	
    for(int i=0;i<x;i++)
    vector[i]=(char*)malloc(10);

    char c;
	int j=0,k=0;
	ssize_t bytesRead;
	while((bytesRead=read(f,&c,1))>0)//asa memorez cuvintele din fisier intr-un vector de cuvinte
	{
	    if(c=='\n'|| c==' ')
	    {
            j++;k=0;
        }
        else{
            vector[j][k]=c;
            k++;
        }
	}

    
	int numara=0;
	for(int i=0;i<x;i++)
	{
	if(strcmp(cuv,vector[i])==0)
	numara++;
	}
	close(f);
	return numara;
}
