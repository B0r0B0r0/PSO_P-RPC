#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<stddef.h>
#include<sys/types.h>
#include<string.h>
#include<math.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
#include<ifaddrs.h>
#include"Per_Process.c"
#include"Hash.h"

void ReturnRequest(uint fd,unsigned char *str)
{
    //aici procesul copil nr2 va executa functia dorita
    //se va ocupa de trimiterea rezultatului catre administrator
    pid_t proces=CreateProcess();
    if(proces==0)
    {

    }
}
void ListenfromAdmin(int fd)
{
    //se trimite socket-ul ca aprametru
    //aici procesul copil va asculta constant mesaje de la server
    // '/' delimitator de pachete

    //forma pachetului primita de la admin 
    // protocol/numeFunct/parametrii
    pid_t proces=CreateProcess();
    if(proces==0)
    {
        char *buffer=malloc(256);
        bzero(buffer,256);
        while (1)
    {
        int n=read(fd,buffer,256);
        if(n>0)
        {
            char *aux=strdup(buffer);
            char *c=malloc(50);
            c=strtok(aux,"/");//acum avem protocolul
            c=strtok(NULL,"/");
            char *numefunc=strdup(c);
            if(strcmp("hash",numefunc)==0);//daca functia ceruta este a noastra atunci o rulam
            {
                c=strtok(NULL,"/");
                ReturnRequest(fd,c);
            }
        }
        bzero(buffer,256);
    }
    }
}

int main(int argc, char** argv)
{
    
    if(argc<3)
    {
        printf("Error!\n");
        exit(0);
    }
    int sock_fd=CreateSocket(argv[1],argv[2]);

    char* buffer=malloc(256);
    bzero(buffer,256);
    strcpy(buffer,"1/");//protocolul
    char *ipAdd=getMyIpAddress();//adresa IP
    strcat(buffer,ipAdd);
    strcat(buffer,"/hash/unsigned char*");//functia si parametrii
    int n=write(sock_fd,buffer,strlen(buffer));


    if(n<0)
    {
        printf("Eroare la trimitere!\n");
        exit(0);
    }

    ListenfromAdmin(sock_fd);

    return 0;
}