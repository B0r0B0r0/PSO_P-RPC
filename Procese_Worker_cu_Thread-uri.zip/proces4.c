#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<stddef.h>
#include<sys/types.h>
#include<string.h>
#include<math.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
#include<ifaddrs.h>
#include"Per_Process.c"
#include"myFrecventa.h"
#include<pthread.h>

typedef struct arguments{
    char* str;
    int fd;
}arguments;

void* ReturnRequest(void* arg)
{
        struct arguments *params=(struct arguments*)arg;
        int fd=params->fd;
        char* str=strdup(params->str);

        char *separa=malloc(10000);
        separa=strtok(str,"/");//aici o sa avem textul
        char *cauta=malloc(10);
        cauta=strtok(NULL,"/");//aici o sa fie cuvantul cautat
        int nr=Frecventa(separa,cauta);
        char* buffer=malloc(10);
        sprintf(buffer,"%d",nr);
        
        int n=write(fd,buffer,strlen(buffer));
        if(n<0)
        {
            printf("Eroare la transmiterea mesajului\n");
            exit(0);
        } 
}
void* ListenfromAdmin(void* fd)
{
        int myfd=*((int*)fd);
        char *buffer=malloc(256);
        bzero(buffer,256);
        pthread_t th2;
        while (1)
    {
        int n=read(myfd,buffer,256);
        if(n>0)
        {
            char *aux=strdup(buffer);
            char *c=malloc(50);
            c=strtok(aux,"/");//acum avem protocolul
            c=strtok(NULL,"/");//numele functiei
            char *numefunc=strdup(c);
            if(strcmp("Frecventa",numefunc)==0);//daca functia ceruta este a noastra atunci o rulam
            {
                c=strtok(NULL,"/");//aici avem paramterii functiei
               // ReturnRequest(fd,c);
                struct arguments params;
                params.fd=myfd;
                params.str=strdup(c);
                pthread_create(&th2,NULL,ReturnRequest,(void*)&params);
                pthread_join(th2,NULL);
            }
        }
        bzero(buffer,256);
    }
}

int main(int argc, char** argv)
{
    
    if(argc<3)
    {
        printf("Error!\n");
        exit(0);
    }
    int sock_fd=CreateSocket(argv[1],argv[2]);
    pthread_t th1;
    char* buffer=malloc(256);
    bzero(buffer,256);
    strcpy(buffer,"1/");//protocolul
     int fd=getpid();
    char* fd_p=malloc(10);
    sprintf(fd_p,"%d",fd);
    strcat(buffer,fd_p);
    strcat(buffer,"/Frecventa/char*/char*");//functia si parametrii
    int n=write(sock_fd,buffer,strlen(buffer));


    if(n<0)
    {
        printf("Eroare la trimitere!\n");
        exit(0);
    }

    //ListenfromAdmin(sock_fd);
    pthread_create(&th1,NULL,ListenfromAdmin,(void*)&sock_fd);
    pthread_join(th1,NULL);

    return 0;
}
