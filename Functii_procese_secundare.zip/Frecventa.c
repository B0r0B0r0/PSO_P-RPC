#include<string.h>
#include<stdlib.h>
#include<stdio.h>
int NrCuvinte (const char* filename)
{
	FILE *f=fopen(filename,"r");
	char cv=fgetc(f);
	int count=1;
	
	if(f==NULL)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	
	while(cv!=EOF)
	{
	    if(cv==' '|| cv=='\n')
	    count++;
	    cv=fgetc(f);
	}
	fclose(f);
	return count;
}

int NrLinii(const char* filename)
{
	FILE *f=fopen(filename,"r");
	if(f==NULL)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	char cv=fgetc(f);
	int count=1;
	
	while(cv!=EOF)
	{
	   if(cv=='\n')
	   count++;
	   
	   cv=fgetc(f);
	}
	fclose(f);
	return count;
}

int Frecventa(const char* filename, char* cuv)
{
	FILE *f=fopen(filename,"r");
	if(f==NULL)
	{
	printf("Eroare la deschiderea fisierului!\n");
	exit(0);
	}
	int x=NrCuvinte(filename);
	char **vector=(char**)malloc(sizeof(char*)*x);
	
	char buffer[10000];
	int i=0;
	int nr=NrLinii(filename);
	
	while(nr>0)
	{
	fgets(buffer,10000,f);
	char* cuvant=(char*)malloc(10);
	cuvant=strtok(buffer," \n");
	
	while(cuvant!=NULL)
	{
	vector[i]=strdup(cuvant);
	i++;
	cuvant=strtok(NULL," \n");
	}
	nr--;
	}
	int numara=0;
	for(int i=0;i<x;i++)
	{
	if(strcmp(cuv,vector[i])==0)
	numara++;
	}
	fclose(f);
	return numara;
}
